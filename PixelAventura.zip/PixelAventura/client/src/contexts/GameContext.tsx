import React, { createContext, ReactNode, useContext, useState } from 'react';

interface GameContextProps {
  score: number;
  setScore: (score: number) => void;
  highScore: number;
  updateHighScore: (score: number) => void;
  gameSettings: {
    difficulty: 'easy' | 'medium' | 'hard';
    soundEnabled: boolean;
  };
  updateDifficulty: (difficulty: 'easy' | 'medium' | 'hard') => void;
  toggleSound: () => void;
}

const defaultContext: GameContextProps = {
  score: 0,
  setScore: () => {},
  highScore: 0,
  updateHighScore: () => {},
  gameSettings: {
    difficulty: 'medium',
    soundEnabled: true,
  },
  updateDifficulty: () => {},
  toggleSound: () => {},
};

const GameContext = createContext<GameContextProps>(defaultContext);

export const GameProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    // Try to load high score from local storage
    const storedScore = localStorage.getItem('pixelAdventureHighScore');
    return storedScore ? parseInt(storedScore, 10) : 0;
  });
  
  const [gameSettings, setGameSettings] = useState({
    difficulty: 'medium' as 'easy' | 'medium' | 'hard',
    soundEnabled: true,
  });
  
  const updateHighScore = (newScore: number) => {
    if (newScore > highScore) {
      setHighScore(newScore);
      localStorage.setItem('pixelAdventureHighScore', newScore.toString());
    }
  };
  
  const updateDifficulty = (difficulty: 'easy' | 'medium' | 'hard') => {
    setGameSettings(prev => ({
      ...prev,
      difficulty,
    }));
  };
  
  const toggleSound = () => {
    setGameSettings(prev => ({
      ...prev,
      soundEnabled: !prev.soundEnabled,
    }));
  };
  
  return (
    <GameContext.Provider
      value={{
        score,
        setScore,
        highScore,
        updateHighScore,
        gameSettings,
        updateDifficulty,
        toggleSound,
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGameContext = () => useContext(GameContext);
