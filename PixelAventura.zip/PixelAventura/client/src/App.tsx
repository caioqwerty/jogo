import { useEffect, useState } from "react";
import Game from "./game/Game";
import { GameProvider } from "./contexts/GameContext";
import { useAudio } from "./lib/stores/useAudio";
import "@fontsource/inter";
import "./index.css";

function App() {
  const [gameStarted, setGameStarted] = useState(false);
  const [showCredits, setShowCredits] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);
  const { setBackgroundMusic, toggleMute, isMuted } = useAudio();
  const [version] = useState("1.0.0");

  // Initialize audio
  useEffect(() => {
    // Load background music
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.5;
    setBackgroundMusic(bgMusic);

    // Create hit sound
    const hitSound = new Audio("/sounds/hit.mp3");
    hitSound.volume = 0.3;
    useAudio.getState().setHitSound(hitSound);

    // Create success sound
    const successSound = new Audio("/sounds/success.mp3");
    successSound.volume = 0.5;
    useAudio.getState().setSuccessSound(successSound);
  }, [setBackgroundMusic]);

  const startGame = () => {
    setGameStarted(true);
    setShowCredits(false);
    setShowInstructions(false);
    
    // Play background music when game starts
    if (!isMuted) {
      const { backgroundMusic } = useAudio.getState();
      backgroundMusic?.play().catch(e => console.log("Audio play prevented:", e));
    }
  };

  const showCreditsScreen = () => {
    setShowCredits(true);
    setShowInstructions(false);
  };

  const showInstructionsScreen = () => {
    setShowInstructions(true);
    setShowCredits(false);
  };

  const handleBackToMenu = () => {
    setShowCredits(false);
    setShowInstructions(false);
  };

  return (
    <GameProvider>
      {!gameStarted ? (
        <div className="menu-container">
          {/* Decorações de fundo */}
          <div className="pixel-decoration pixel-tree" style={{ top: '10%', left: '10%' }}></div>
          <div className="pixel-decoration pixel-tree" style={{ top: '20%', left: '85%' }}></div>
          <div className="pixel-decoration pixel-tree" style={{ top: '70%', left: '15%' }}></div>
          <div className="pixel-decoration pixel-tree" style={{ top: '65%', left: '80%' }}></div>

          <div className="menu pixel-border">
            <h1 className="menu-title">Aventura Pixel</h1>
            <div className="menu-subtitle">Uma aventura de pixel art em 2D</div>

            {!showCredits && !showInstructions ? (
              <>
                <button className="menu-button" onClick={startGame}>Jogar</button>
                <button className="menu-button" onClick={showInstructionsScreen}>Instruções</button>
                <button className="menu-button" onClick={showCreditsScreen}>Créditos</button>
                <button 
                  className="menu-button sound-button" 
                  onClick={toggleMute}
                >
                  {isMuted ? "🔇 Som Desligado" : "🔊 Som Ligado"}
                </button>
                <div style={{ fontSize: '12px', color: '#aaa', marginTop: '20px' }}>
                  Versão {version}
                </div>
              </>
            ) : null}
            
            {showCredits && (
              <div className="credits">
                <h2>Créditos</h2>
                
                <div className="credits-category">Equipe de Desenvolvimento</div>
                <div className="credits-item">
                  <span className="credits-name">Replit Agent</span>
                  <span className="credits-role">Desenvolvedor</span>
                </div>
                <div className="credits-item">
                  <span className="credits-name">Você</span>
                  <span className="credits-role">Diretor Criativo</span>
                </div>
                
                <div className="credits-category">Design</div>
                <div className="credits-item">
                  <span className="credits-name">Aventura Pixel Team</span>
                  <span className="credits-role">Arte & Gráficos</span>
                </div>
                
                <div className="credits-category">Música e Sons</div>
                <div className="credits-item">
                  <span className="credits-name">Replit Studio</span>
                  <span className="credits-role">Efeitos Sonoros</span>
                </div>
                
                <div className="credits-category">Agradecimentos Especiais</div>
                <p>A todos que contribuíram para o desenvolvimento e teste deste jogo.</p>
                
                <button className="menu-button back-button" onClick={handleBackToMenu}>
                  Voltar
                </button>
              </div>
            )}

            {showInstructions && (
              <div className="credits">
                <h2>Como Jogar</h2>
                
                <div className="credits-category">Controles</div>
                <ul>
                  <li>Use as <strong>setas</strong> ou <strong>WASD</strong> para mover o personagem</li>
                  <li>Pressione <strong>espaço</strong> para atirar projéteis</li>
                  <li>Tecla <strong>P</strong> para pausar o jogo</li>
                  <li>Tecla <strong>ESC</strong> para voltar ao menu</li>
                </ul>
                
                <div className="credits-category">Objetivo</div>
                <p>Colete itens e derrote inimigos para ganhar pontos. Cada inimigo vale 20 pontos e cada item coletável vale 10 pontos.</p>
                
                <div className="credits-category">Mini-mapa</div>
                <p>Use o mini-mapa no canto inferior direito para navegar pelo mundo do jogo. Inimigos são marcados em vermelho, coletáveis em amarelo e o jogador em verde.</p>
                
                <div className="credits-category">Inimigos</div>
                <p>Existem três tipos diferentes de inimigos, cada um com sua própria aparência:</p>
                <ul>
                  <li><strong>Inimigos Vermelhos</strong> - Quadrados com movimento rápido e agressivo</li>
                  <li><strong>Inimigos Roxos</strong> - Triângulos que te perseguem em grupo</li>
                  <li><strong>Inimigos Laranja</strong> - Círculos que são mais lentos mas resistentes</li>
                </ul>
                
                <div className="credits-category">Obstáculos</div>
                <p>O mapa contém vários tipos de obstáculos:</p>
                <ul>
                  <li><strong>Árvores</strong> - Bloqueiam o movimento, mas podem ser contornadas</li>
                  <li><strong>Pedras</strong> - Obstáculos menores espalhados pelo mapa</li>
                  <li><strong>Muros</strong> - Bordas do mapa que impedem que você saia da área de jogo</li>
                </ul>
                
                <div className="credits-category">Níveis</div>
                <p>À medida que você elimina inimigos e coleta itens, o nível aumenta. Cada nível traz mais inimigos e coletáveis, aumentando o desafio e a recompensa.</p>
                
                <div className="credits-category">Dicas</div>
                <ul>
                  <li>Use os obstáculos a seu favor para escapar dos inimigos</li>
                  <li>Projéteis se destroem ao atingir obstáculos ou inimigos</li>
                  <li>Fique de olho no mini-mapa para localizar todos os coletáveis</li>
                  <li>Use movimentos estratégicos para atrair inimigos para longe dos coletáveis</li>
                </ul>
                
                <button className="menu-button back-button" onClick={handleBackToMenu}>
                  Voltar
                </button>
              </div>
            )}
          </div>

          <div className="controls-info">
            Controles: Setas/WASD para mover, Espaço para atirar
          </div>
        </div>
      ) : (
        <Game onBackToMenu={() => setGameStarted(false)} />
      )}
    </GameProvider>
  );
}

export default App;
