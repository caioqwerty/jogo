import { Sprite } from './Sprite';

export class Projectile extends Sprite {
  speed: number;
  direction: 'left' | 'right' | 'up' | 'down';
  lifespan: number;
  animationPhase: number;
  glowIntensity: number;
  trailLength: number;
  particles: {x: number, y: number, size: number, alpha: number}[];
  
  constructor(x: number, y: number, direction: 'left' | 'right' | 'up' | 'down') {
    // Projétil um pouco maior para melhor visibilidade
    super(x, y, 10, 10);
    this.speed = 7;
    this.direction = direction;
    this.lifespan = 2; // Duração em segundos
    this.animationPhase = 0;
    this.glowIntensity = 1.0;
    this.trailLength = 5;
    this.particles = [];
    
    // Criar algumas partículas iniciais
    for (let i = 0; i < 3; i++) {
      this.addTrailParticle();
    }
  }
  
  update(deltaTime: number): void {
    // Salvar posição anterior para efeito de trilha
    const previousX = this.x;
    const previousY = this.y;
    
    // Mover o projétil com base na direção
    switch (this.direction) {
      case 'up':
        this.y -= this.speed;
        break;
      case 'down':
        this.y += this.speed;
        break;
      case 'left':
        this.x -= this.speed;
        break;
      case 'right':
        this.x += this.speed;
        break;
    }
    
    // Atualizar animação
    this.animationPhase += deltaTime * 10;
    this.glowIntensity = 0.7 + Math.sin(this.animationPhase) * 0.3; // Efeito de pulsação
    
    // Atualizar partículas existentes
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.alpha -= deltaTime * 2; // Desvanecer gradualmente
      p.size -= deltaTime * 5; // Encolher gradualmente
      
      if (p.alpha <= 0 || p.size <= 0) {
        this.particles.splice(i, 1);
      }
    }
    
    // Adicionar novas partículas com base no movimento
    if (Math.abs(this.x - previousX) > 0 || Math.abs(this.y - previousY) > 0) {
      this.addTrailParticle();
    }
    
    // Reduzir a duração
    this.lifespan -= deltaTime;
  }
  
  addTrailParticle() {
    let offsetX = 0;
    let offsetY = 0;
    
    // Adicionar partícula atrás do projétil (com base na direção)
    switch (this.direction) {
      case 'up':
        offsetX = this.width / 2;
        offsetY = this.height;
        break;
      case 'down':
        offsetX = this.width / 2;
        offsetY = 0;
        break;
      case 'left':
        offsetX = this.width;
        offsetY = this.height / 2;
        break;
      case 'right':
        offsetX = 0;
        offsetY = this.height / 2;
        break;
    }
    
    // Adicionar um pouco de randomização para dar um efeito mais natural
    offsetX += (Math.random() - 0.5) * 2;
    offsetY += (Math.random() - 0.5) * 2;
    
    this.particles.push({
      x: this.x + offsetX,
      y: this.y + offsetY,
      size: this.width / 2 * (0.7 + Math.random() * 0.3), // Tamanho variável
      alpha: 0.7 + Math.random() * 0.3 // Transparência variável
    });
  }
  
  draw(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    
    // Desenhar partículas de trilha primeiro (para ficarem atrás do projétil)
    this.particles.forEach(p => {
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = '#FFD54F'; // Amarelo mais claro para a trilha
      
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    });
    
    // Restaurar opacidade para o projétil principal
    ctx.globalAlpha = 1;
    
    // Adicionar sombra para dar profundidade
    ctx.shadowColor = 'rgba(255, 235, 59, 0.7)';
    ctx.shadowBlur = 15 * this.glowIntensity;
    
    // Calcular centro do projétil
    const centerX = this.x + this.width / 2;
    const centerY = this.y + this.height / 2;
    const radius = this.width / 2;
    
    // Criar efeito de brilho externo
    const glow = ctx.createRadialGradient(
      centerX, centerY, radius * 0.2,
      centerX, centerY, radius * 2
    );
    glow.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
    glow.addColorStop(0.3, 'rgba(255, 235, 59, 0.6)');
    glow.addColorStop(1, 'rgba(255, 235, 59, 0)');
    
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 2, 0, Math.PI * 2);
    ctx.fill();
    
    // Desenhar o núcleo principal do projétil
    ctx.fillStyle = '#FFEB3B'; // Amarelo brilhante
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.8, 0, Math.PI * 2);
    ctx.fill();
    
    // Adicionar brilho central
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.4, 0, Math.PI * 2);
    ctx.fill();
    
    // Adicionar um detalhe visual baseado na direção
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    let startX, startY, endX, endY;
    
    switch (this.direction) {
      case 'up':
        startX = centerX;
        startY = centerY - radius * 0.4;
        endX = centerX;
        endY = centerY - radius * 1.2;
        break;
      case 'down':
        startX = centerX;
        startY = centerY + radius * 0.4;
        endX = centerX;
        endY = centerY + radius * 1.2;
        break;
      case 'left':
        startX = centerX - radius * 0.4;
        startY = centerY;
        endX = centerX - radius * 1.2;
        endY = centerY;
        break;
      case 'right':
        startX = centerX + radius * 0.4;
        startY = centerY;
        endX = centerX + radius * 1.2;
        endY = centerY;
        break;
    }
    
    // Desenhar linha direcional com opacidade variável
    const lineShadow = ctx.createLinearGradient(startX, startY, endX, endY);
    lineShadow.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
    lineShadow.addColorStop(1, 'rgba(255, 255, 255, 0)');
    
    ctx.strokeStyle = lineShadow;
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(endX, endY);
    ctx.stroke();
    
    ctx.restore();
  }
}