export class Map {
  width: number;
  height: number;
  tileSize: number;
  obstacles: { x: number; y: number; width: number; height: number }[];
  borderWidth: number;
  objectType: ('rock' | 'tree')[];

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.tileSize = 32;
    this.obstacles = [];
    this.objectType = [];
    this.borderWidth = 20; // Largura da borda do mapa
    
    // Create some obstacles
    this.generateObstacles();
  }

  generateObstacles(): void {
    // Limpar obstáculos existentes
    this.obstacles = [];
    this.objectType = [];
    
    // Adicionar bordas como obstáculos
    // Top border
    this.obstacles.push({ 
      x: 0, 
      y: 0, 
      width: this.width, 
      height: this.borderWidth 
    });
    this.objectType.push('rock'); // Tipo apenas para controle interno
    
    // Bottom border
    this.obstacles.push({ 
      x: 0, 
      y: this.height - this.borderWidth, 
      width: this.width, 
      height: this.borderWidth 
    });
    this.objectType.push('rock');
    
    // Left border
    this.obstacles.push({ 
      x: 0, 
      y: 0, 
      width: this.borderWidth, 
      height: this.height 
    });
    this.objectType.push('rock');
    
    // Right border
    this.obstacles.push({ 
      x: this.width - this.borderWidth, 
      y: 0, 
      width: this.borderWidth, 
      height: this.height 
    });
    this.objectType.push('rock');
    
    // Add some rocks and trees randomly
    const rockCount = 8;
    const treeCount = 10;
    
    // Generate rocks - evitando colocar muito perto das bordas
    for (let i = 0; i < rockCount; i++) {
      const x = Math.random() * (this.width - this.tileSize * 2 - this.borderWidth * 2) + this.borderWidth;
      const y = Math.random() * (this.height - this.tileSize * 2 - this.borderWidth * 2) + this.borderWidth;
      const size = Math.random() * 20 + 30;
      
      // Evitar obstáculos perto do centro (posição inicial do jogador)
      const centerX = this.width / 2;
      const centerY = this.height / 2;
      const distanceFromCenter = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));
      
      if (distanceFromCenter > 100) {
        this.obstacles.push({
          x,
          y,
          width: size,
          height: size,
        });
        this.objectType.push('rock');
      }
    }
    
    // Generate trees - evitando colocar muito perto das bordas
    for (let i = 0; i < treeCount; i++) {
      const x = Math.random() * (this.width - this.tileSize * 2 - this.borderWidth * 2) + this.borderWidth;
      const y = Math.random() * (this.height - this.tileSize * 2 - this.borderWidth * 2) + this.borderWidth;
      
      // Evitar obstáculos perto do centro (posição inicial do jogador)
      const centerX = this.width / 2;
      const centerY = this.height / 2;
      const distanceFromCenter = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));
      
      if (distanceFromCenter > 100) {
        this.obstacles.push({
          x,
          y,
          width: 40,
          height: 60,
        });
        this.objectType.push('tree');
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D): void {
    // Draw grass background
    ctx.fillStyle = '#9ACD32';
    ctx.fillRect(0, 0, this.width, this.height);
    
    // Draw texture pattern to make it look more like grass
    for (let y = 0; y < this.height; y += this.tileSize) {
      for (let x = 0; x < this.width; x += this.tileSize) {
        // Add slight color variations to grass
        if (Math.random() > 0.8) {
          ctx.fillStyle = '#8FBC8F';
          ctx.fillRect(
            x + Math.random() * this.tileSize,
            y + Math.random() * this.tileSize,
            5 + Math.random() * 10,
            5 + Math.random() * 10
          );
        }
      }
    }
    
    // Draw obstacles
    this.obstacles.forEach((obstacle, index) => {
      // Identificar se é uma borda
      const isBorder = index < 4; // Os 4 primeiros obstáculos são as bordas
      
      if (isBorder) {
        // Desenhar bordas do mapa como muros de pedra
        ctx.fillStyle = '#555555'; // Cinza escuro para muros
        ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
        
        // Adicionar textura de pedras ao muro
        ctx.strokeStyle = '#444444';
        ctx.lineWidth = 1;
        
        // Textura horizontal para bordas superior e inferior
        if (index === 0 || index === 1) {
          for (let x = obstacle.x; x < obstacle.x + obstacle.width; x += 20) {
            for (let y = obstacle.y; y < obstacle.y + obstacle.height; y += 10) {
              ctx.strokeRect(x, y, 20, 10);
            }
          }
        } 
        // Textura vertical para bordas laterais
        else {
          for (let x = obstacle.x; x < obstacle.x + obstacle.width; x += 10) {
            for (let y = obstacle.y; y < obstacle.y + obstacle.height; y += 20) {
              ctx.strokeRect(x, y, 10, 20);
            }
          }
        }
      } else if (this.objectType[index] === 'rock') {
        // Desenhar pedras
        ctx.fillStyle = '#808080';
        ctx.beginPath();
        ctx.ellipse(
          obstacle.x + obstacle.width / 2,
          obstacle.y + obstacle.height / 2, 
          obstacle.width / 2,
          obstacle.height / 2,
          0,
          0,
          Math.PI * 2
        );
        ctx.fill();
        
        // Adicionar detalhes à pedra
        ctx.fillStyle = '#A9A9A9';
        ctx.beginPath();
        ctx.ellipse(
          obstacle.x + obstacle.width / 3,
          obstacle.y + obstacle.height / 3, 
          obstacle.width / 6,
          obstacle.height / 6,
          0,
          0,
          Math.PI * 2
        );
        ctx.fill();
      } else {
        // Desenhar árvores
        // Tronco
        ctx.fillStyle = '#8B4513';
        ctx.fillRect(
          obstacle.x + obstacle.width / 3,
          obstacle.y + obstacle.height / 2,
          obstacle.width / 3,
          obstacle.height / 2
        );
        
        // Folhas
        ctx.fillStyle = '#228B22';
        ctx.beginPath();
        ctx.arc(
          obstacle.x + obstacle.width / 2,
          obstacle.y + obstacle.height / 3,
          obstacle.width / 2,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }
    });
  }
}
