import { Sprite } from './Sprite';
import { Map } from './Map';

// Tipo para representar a caixa de colisão
export type CollisionBox = {
  x: number;
  y: number;
  width: number;
  height: number;
};

export class CollisionDetector {
  constructor() {
    // Initialization if needed
  }

  checkCollision(sprite1: Sprite, sprite2: Sprite): boolean {
    // Get collision boxes for both sprites
    const box1 = sprite1.getCollisionBox();
    const box2 = sprite2.getCollisionBox();
    
    // Perform AABB collision detection
    return (
      box1.x < box2.x + box2.width &&
      box1.x + box1.width > box2.x &&
      box1.y < box2.y + box2.height &&
      box1.y + box1.height > box2.y
    );
  }

  // Verifica colisão entre uma caixa de colisão e um sprite
  checkBoxCollision(box: CollisionBox, sprite: Sprite): boolean {
    const spriteBox = sprite.getCollisionBox();
    
    return (
      box.x < spriteBox.x + spriteBox.width &&
      box.x + box.width > spriteBox.x &&
      box.y < spriteBox.y + spriteBox.height &&
      box.y + box.height > spriteBox.y
    );
  }

  // Verifica colisão entre duas caixas de colisão
  checkBoxToBoxCollision(box1: CollisionBox, box2: CollisionBox): boolean {
    return (
      box1.x < box2.x + box2.width &&
      box1.x + box1.width > box2.x &&
      box1.y < box2.y + box2.height &&
      box1.y + box1.height > box2.y
    );
  }

  // Verifica colisão do jogador com obstáculos do mapa
  checkMapCollision(sprite: Sprite, map: Map): boolean {
    const box = sprite.getCollisionBox();
    
    // Verificar colisão com cada obstáculo do mapa
    for (const obstacle of map.obstacles) {
      if (this.checkBoxToBoxCollision(box, obstacle)) {
        return true;
      }
    }
    
    return false;
  }

  // Verifica colisão em uma direção específica e retorna a posição segura
  // com ajustes mais sofisticados para navegação suave
  checkMapCollisionWithAdjustment(
    sprite: Sprite, 
    map: Map, 
    newX: number, 
    newY: number
  ): { x: number, y: number } {
    // Cria caixas de colisão para cada direção de movimento
    const currentBox = sprite.getCollisionBox();
    const movingRight = newX > sprite.x;
    const movingDown = newY > sprite.y;
    
    // Posição inicial
    let validX = newX;
    let validY = newY;
    
    // Identificar qual obstáculo está causando a colisão (se houver)
    let collidingObstacle: CollisionBox | null = null;
    
    // Teste movimento horizontal primeiro
    const horizontalBox: CollisionBox = {
      x: newX,
      y: currentBox.y,
      width: currentBox.width,
      height: currentBox.height
    };
    
    // Verificar colisão horizontal
    for (const obstacle of map.obstacles) {
      if (this.checkBoxToBoxCollision(horizontalBox, obstacle)) {
        // Houve colisão horizontal, manter X atual
        validX = sprite.x;
        collidingObstacle = obstacle;
        break;
      }
    }
    
    // Teste movimento vertical com X já validado
    const verticalBox: CollisionBox = {
      x: validX, // Usar X já validado
      y: newY,
      width: currentBox.width,
      height: currentBox.height
    };
    
    // Verificar colisão vertical
    for (const obstacle of map.obstacles) {
      if (this.checkBoxToBoxCollision(verticalBox, obstacle)) {
        // Houve colisão vertical, manter Y atual
        validY = sprite.y;
        collidingObstacle = obstacle;
        break;
      }
    }
    
    // Se houve colisão e é um inimigo, tentar ajustes adicionais para evitar ficar preso
    const isEnemy = sprite.constructor.name === 'Enemy';
    
    if (isEnemy && collidingObstacle && (validX === sprite.x || validY === sprite.y)) {
      // Tenta ajustar a posição para deslizar ao longo do obstáculo
      const slideAmount = 3; // Quantidade de deslizamento para evitar ficar preso
      
      // Verificar se podemos deslizar horizontalmente ou verticalmente
      if (validX === sprite.x) {
        // Temos uma colisão horizontal, tentar deslizar verticalmente
        const slideUp: CollisionBox = {
          x: validX,
          y: sprite.y - slideAmount,
          width: currentBox.width,
          height: currentBox.height
        };
        
        const slideDown: CollisionBox = {
          x: validX,
          y: sprite.y + slideAmount,
          width: currentBox.width,
          height: currentBox.height
        };
        
        // Verificar se podemos deslizar para cima
        let canSlideUp = true;
        let canSlideDown = true;
        
        for (const obstacle of map.obstacles) {
          if (this.checkBoxToBoxCollision(slideUp, obstacle)) {
            canSlideUp = false;
          }
          if (this.checkBoxToBoxCollision(slideDown, obstacle)) {
            canSlideDown = false;
          }
        }
        
        // Escolher a direção de deslizamento com base na direção desejada de movimento
        if ((movingDown && canSlideDown) || (!movingDown && !canSlideUp && canSlideDown)) {
          validY = sprite.y + slideAmount;
        } else if ((!movingDown && canSlideUp) || (movingDown && !canSlideDown && canSlideUp)) {
          validY = sprite.y - slideAmount;
        }
      }
      
      if (validY === sprite.y) {
        // Temos uma colisão vertical, tentar deslizar horizontalmente
        const slideLeft: CollisionBox = {
          x: sprite.x - slideAmount,
          y: validY,
          width: currentBox.width,
          height: currentBox.height
        };
        
        const slideRight: CollisionBox = {
          x: sprite.x + slideAmount,
          y: validY,
          width: currentBox.width,
          height: currentBox.height
        };
        
        // Verificar se podemos deslizar
        let canSlideLeft = true;
        let canSlideRight = true;
        
        for (const obstacle of map.obstacles) {
          if (this.checkBoxToBoxCollision(slideLeft, obstacle)) {
            canSlideLeft = false;
          }
          if (this.checkBoxToBoxCollision(slideRight, obstacle)) {
            canSlideRight = false;
          }
        }
        
        // Escolher a direção de deslizamento com base na direção desejada de movimento
        if ((movingRight && canSlideRight) || (!movingRight && !canSlideLeft && canSlideRight)) {
          validX = sprite.x + slideAmount;
        } else if ((!movingRight && canSlideLeft) || (movingRight && !canSlideRight && canSlideLeft)) {
          validX = sprite.x - slideAmount;
        }
      }
    }
    
    // Verificar limites do mapa para garantir que entidade não saia do mapa
    validX = Math.max(0, Math.min(map.width - currentBox.width, validX));
    validY = Math.max(0, Math.min(map.height - currentBox.height, validY));
    
    return { x: validX, y: validY };
  }

  checkPointCollision(
    x: number, 
    y: number, 
    sprite: Sprite
  ): boolean {
    const box = sprite.getCollisionBox();
    
    return (
      x >= box.x &&
      x <= box.x + box.width &&
      y >= box.y &&
      y <= box.y + box.height
    );
  }
}
