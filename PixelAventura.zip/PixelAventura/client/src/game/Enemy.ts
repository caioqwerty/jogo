import { Sprite } from './Sprite';
import { Player } from './Player';
import { Map } from './Map';
import { CollisionDetector } from './CollisionDetector';

export class Enemy extends Sprite {
  speed: number;
  chaseRange: number;
  frameX: number;
  frameTimer: number;
  frameInterval: number;
  maxFrames: number;
  enemyType: number;
  lastValidPosition: { x: number, y: number };
  avoidanceTimer: number;
  avoidanceDirection: { x: number, y: number };

  constructor(x: number, y: number, width: number, height: number, speed: number) {
    super(x, y, width, height);
    this.speed = speed;
    this.chaseRange = 200; // Range at which enemy starts chasing player
    this.frameX = 0;
    this.frameTimer = 0;
    this.frameInterval = 0.2;
    this.maxFrames = 2;
    this.enemyType = Math.floor(Math.random() * 3); // 0, 1, or 2 for different enemy types
    this.lastValidPosition = { x, y };
    this.avoidanceTimer = 0;
    this.avoidanceDirection = { x: 0, y: 0 };
  }

  update(deltaTime: number, player: Player, map?: Map, collisionDetector?: CollisionDetector): void {
    // Salvar posição atual antes de mover
    this.lastValidPosition = { x: this.x, y: this.y };
    
    // Calculate distance to player
    const dx = player.x - this.x;
    const dy = player.y - this.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    // Decrementar timer de comportamento de desvio
    if (this.avoidanceTimer > 0) {
      this.avoidanceTimer -= deltaTime;
    }
    
    // If player within chase range, move toward player
    if (distance < this.chaseRange) {
      // Calcular direção normal para o jogador
      const length = Math.sqrt(dx * dx + dy * dy) || 1; // Evitar divisão por zero
      let dirX = dx / length;
      let dirY = dy / length;
      
      // Se estiver em modo de desvio, usar direção alternativa
      if (this.avoidanceTimer > 0) {
        dirX = this.avoidanceDirection.x;
        dirY = this.avoidanceDirection.y;
      }
      
      // Calcular nova posição, com movimento mais lento quando estiver desviando
      const speedMultiplier = this.avoidanceTimer > 0 ? 1.2 : 1.0; // Aumentar velocidade durante desvio
      const newX = this.x + dirX * this.speed * speedMultiplier;
      const newY = this.y + dirY * this.speed * speedMultiplier;
      
      // Sistemas de detecção e tratamento de colisões
      if (map && collisionDetector) {
        // Testar movimento separado em X e Y para melhor navegação em cantos
        const xOnlyPosition = collisionDetector.checkMapCollisionWithAdjustment(
          this,
          map,
          newX,
          this.y
        );
        
        const yOnlyPosition = collisionDetector.checkMapCollisionWithAdjustment(
          this,
          map,
          this.x,
          newY
        );
        
        // Verificar se estamos bloqueados em ambas as direções
        const blockedX = xOnlyPosition.x === this.x;
        const blockedY = yOnlyPosition.y === this.y;
        
        // Se estivermos bloqueados em ambas as direções, é provável que estejamos presos em um canto
        if (blockedX && blockedY) {
          // Forçar uma mudança significativa de direção
          this.avoidanceTimer = 2.0; // Tempo mais longo para escapar
          
          // Tentar uma direção oposta à direção do jogador (fugir do canto)
          this.avoidanceDirection = {
            x: -dirX + (Math.random() * 0.4 - 0.2), // Adicionar um pouco de aleatoriedade
            y: -dirY + (Math.random() * 0.4 - 0.2)
          };
          
          // Normalizar vetor de direção
          const avoidLen = Math.sqrt(
            this.avoidanceDirection.x * this.avoidanceDirection.x + 
            this.avoidanceDirection.y * this.avoidanceDirection.y
          ) || 1;
          
          this.avoidanceDirection.x /= avoidLen;
          this.avoidanceDirection.y /= avoidLen;
        }
        // Se estivermos bloqueados em uma direção, mas não na outra, podemos nos mover na direção livre
        else if (blockedX || blockedY) {
          if (this.avoidanceTimer <= 0) {
            this.avoidanceTimer = 1.0;
            
            // Se X está bloqueado, priorizar movimento em Y, e vice-versa
            if (blockedX) {
              this.avoidanceDirection = {
                x: 0,
                y: dirY > 0 ? 1 : -1
              };
            } else {
              this.avoidanceDirection = {
                x: dirX > 0 ? 1 : -1,
                y: 0
              };
            }
          }
        }
        
        // Testar a posição combinada final
        const finalPosition = collisionDetector.checkMapCollisionWithAdjustment(
          this,
          map,
          newX,
          newY
        );
        
        // Verificar se ainda estamos parados mesmo após tentar desviar
        if (this.avoidanceTimer > 0 && 
            finalPosition.x === this.x && 
            finalPosition.y === this.y) {
            
          // Estamos completamente bloqueados, tentar uma direção completamente aleatória
          const randomAngle = Math.random() * Math.PI * 2;
          this.avoidanceDirection = {
            x: Math.cos(randomAngle),
            y: Math.sin(randomAngle)
          };
          
          // Tentar uma movimentação pequena na direção aleatória
          const escapeX = this.x + this.avoidanceDirection.x * 5;
          const escapeY = this.y + this.avoidanceDirection.y * 5;
          
          const escapePosition = collisionDetector.checkMapCollisionWithAdjustment(
            this,
            map,
            escapeX,
            escapeY
          );
          
          // Se conseguimos nos mover um pouco, use essa posição
          if (escapePosition.x !== this.x || escapePosition.y !== this.y) {
            finalPosition.x = escapePosition.x;
            finalPosition.y = escapePosition.y;
          }
        }
        
        // Atualizar com posição válida
        this.x = finalPosition.x;
        this.y = finalPosition.y;
        
        // Se não conseguimos nos mover de forma alguma, aumentar o timer de desvio
        // e tentar uma nova direção aleatória na próxima atualização
        if (this.x === this.lastValidPosition.x && this.y === this.lastValidPosition.y) {
          this.avoidanceTimer = Math.max(this.avoidanceTimer, 0.5);
          
          // Gerar uma nova direção completamente aleatória
          const randomAngle = Math.random() * Math.PI * 2;
          this.avoidanceDirection = {
            x: Math.cos(randomAngle),
            y: Math.sin(randomAngle)
          };
        }
      } else {
        // Se não há detector de colisão, mover diretamente
        this.x = newX;
        this.y = newY;
      }
      
      // Update animation frame - alternar mais rápido quando estiver no modo de desvio
      const frameSpeed = this.avoidanceTimer > 0 ? this.frameInterval * 0.7 : this.frameInterval;
      this.frameTimer += deltaTime;
      if (this.frameTimer >= frameSpeed) {
        this.frameTimer = 0;
        this.frameX = (this.frameX + 1) % this.maxFrames;
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    
    // Calcular centro do inimigo para desenho
    const centerX = this.x + this.width / 2;
    const centerY = this.y + this.height / 2;
    
    // Adicionar sombra para dar profundidade
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = 5;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;
    
    // Cores e configurações específicas para cada tipo de inimigo
    switch (this.enemyType) {
      case 0: // Inimigo quadrado vermelho
        // Criar gradiente para dar profundidade
        const redGradient = ctx.createLinearGradient(this.x, this.y, this.x, this.y + this.height);
        redGradient.addColorStop(0, '#FF5252'); // Vermelho claro
        redGradient.addColorStop(1, '#D32F2F'); // Vermelho escuro
        
        // Desenhar corpo com cantos arredondados
        const radius = 5;
        ctx.fillStyle = redGradient;
        
        // Desenhar retângulo arredondado
        ctx.beginPath();
        ctx.moveTo(this.x + radius, this.y);
        ctx.lineTo(this.x + this.width - radius, this.y);
        ctx.quadraticCurveTo(this.x + this.width, this.y, this.x + this.width, this.y + radius);
        ctx.lineTo(this.x + this.width, this.y + this.height - radius);
        ctx.quadraticCurveTo(this.x + this.width, this.y + this.height, this.x + this.width - radius, this.y + this.height);
        ctx.lineTo(this.x + radius, this.y + this.height);
        ctx.quadraticCurveTo(this.x, this.y + this.height, this.x, this.y + this.height - radius);
        ctx.lineTo(this.x, this.y + radius);
        ctx.quadraticCurveTo(this.x, this.y, this.x + radius, this.y);
        ctx.closePath();
        ctx.fill();
        
        // Adicionar contorno
        ctx.strokeStyle = '#B71C1C';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        
        // Remover sombra para detalhes precisos
        ctx.shadowColor = 'transparent';
        
        // Desenhar olhos (mais expressivos, com sobrancelhas)
        const eyeSize = 7;
        const eyeSpacing = 14;
        const eyeY = this.y + this.height * 0.35;
        
        // Sobrancelhas anguladas (parecem mais malvadas)
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        
        // Sobrancelha esquerda
        ctx.beginPath();
        ctx.moveTo(centerX - eyeSpacing / 2 - 5, eyeY - 5);
        ctx.lineTo(centerX - eyeSpacing / 2 + 5, eyeY - 8);
        ctx.stroke();
        
        // Sobrancelha direita
        ctx.beginPath();
        ctx.moveTo(centerX + eyeSpacing / 2 - 5, eyeY - 8);
        ctx.lineTo(centerX + eyeSpacing / 2 + 5, eyeY - 5);
        ctx.stroke();
        
        // Olhos (branco)
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(centerX - eyeSpacing / 2, eyeY, eyeSize, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(centerX + eyeSpacing / 2, eyeY, eyeSize, 0, Math.PI * 2);
        ctx.fill();
        
        // Pupilas (olhando para o jogador)
        ctx.fillStyle = '#880000';
        const pupilSize = 3;
        ctx.beginPath();
        ctx.arc(centerX - eyeSpacing / 2 - 1, eyeY - 1, pupilSize, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(centerX + eyeSpacing / 2 + 1, eyeY - 1, pupilSize, 0, Math.PI * 2);
        ctx.fill();
        
        // Boca com dentes (mais ameaçadora)
        const mouthY = this.y + this.height * 0.7;
        
        // Forma de boca maligna
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.moveTo(centerX - 10, mouthY);
        ctx.lineTo(centerX - 5, mouthY + 3);
        ctx.lineTo(centerX, mouthY);
        ctx.lineTo(centerX + 5, mouthY + 3);
        ctx.lineTo(centerX + 10, mouthY);
        ctx.lineTo(centerX + 5, mouthY + 5);
        ctx.lineTo(centerX, mouthY + 3);
        ctx.lineTo(centerX - 5, mouthY + 5);
        ctx.closePath();
        ctx.fill();
        
        // Adicionar detalhes (como chifres pequenos para um visual mais malígno)
        ctx.fillStyle = '#B71C1C';
        
        // Chifre esquerdo
        ctx.beginPath();
        ctx.moveTo(this.x + 10, this.y);
        ctx.lineTo(this.x + 5, this.y - 8);
        ctx.lineTo(this.x + 15, this.y);
        ctx.fill();
        
        // Chifre direito
        ctx.beginPath();
        ctx.moveTo(this.x + this.width - 10, this.y);
        ctx.lineTo(this.x + this.width - 5, this.y - 8);
        ctx.lineTo(this.x + this.width - 15, this.y);
        ctx.fill();
        break;
        
      case 1: // Inimigo roxo (estilo triângulo)
        // Criar gradiente para o corpo
        const purpleGradient = ctx.createLinearGradient(this.x, this.y, this.x, this.y + this.height);
        purpleGradient.addColorStop(0, '#9C27B0');  // Roxo normal
        purpleGradient.addColorStop(1, '#7B1FA2');  // Roxo mais escuro
        
        ctx.fillStyle = purpleGradient;
        
        // Desenhar corpo em forma de diamante
        ctx.beginPath();
        ctx.moveTo(centerX, this.y); // Topo
        ctx.lineTo(this.x + this.width, centerY); // Direita
        ctx.lineTo(centerX, this.y + this.height); // Base
        ctx.lineTo(this.x, centerY); // Esquerda
        ctx.closePath();
        ctx.fill();
        
        // Contorno
        ctx.strokeStyle = '#4A148C';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        
        // Remover sombra para detalhes
        ctx.shadowColor = 'transparent';
        
        // Olho único central (estilo cíclope)
        const cyclopEyeSize = 12;
        
        // Branco do olho
        ctx.fillStyle = '#E1BEE7'; // Lavanda claro
        ctx.beginPath();
        ctx.arc(centerX, centerY, cyclopEyeSize, 0, Math.PI * 2);
        ctx.fill();
        
        // Pupila
        ctx.fillStyle = '#4A148C'; // Roxo escuro
        ctx.beginPath();
        ctx.arc(centerX, centerY, cyclopEyeSize * 0.6, 0, Math.PI * 2);
        ctx.fill();
        
        // Brilho no olho
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(centerX - 2, centerY - 2, 3, 0, Math.PI * 2);
        ctx.fill();
        
        // Padrões no corpo (runas ou marcações)
        ctx.strokeStyle = '#CE93D8'; // Roxo claro
        ctx.lineWidth = 1;
        
        // Padrão superior
        ctx.beginPath();
        ctx.moveTo(centerX, this.y + 10);
        ctx.lineTo(centerX, this.y + 20);
        ctx.stroke();
        
        // Padrões laterais
        ctx.beginPath();
        ctx.moveTo(this.x + 10, centerY);
        ctx.lineTo(this.x + 20, centerY);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(this.x + this.width - 10, centerY);
        ctx.lineTo(this.x + this.width - 20, centerY);
        ctx.stroke();
        
        // Efeito de brilho/energia
        if (this.frameX % 2 === 0) {
          ctx.strokeStyle = 'rgba(206, 147, 216, 0.5)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(centerX, centerY, this.width * 0.7, 0, Math.PI * 2);
          ctx.stroke();
        }
        break;
        
      case 2: // Inimigo laranja (estilo circular)
        // Criar gradiente radial para corpo circular
        const orangeGradient = ctx.createRadialGradient(
          centerX, centerY, 0,
          centerX, centerY, this.width / 2
        );
        orangeGradient.addColorStop(0, '#FFA726'); // Laranja claro no centro
        orangeGradient.addColorStop(0.8, '#EF6C00'); // Laranja normal
        orangeGradient.addColorStop(1, '#E65100'); // Laranja escuro na borda
        
        ctx.fillStyle = orangeGradient;
        
        // Desenhar corpo circular
        ctx.beginPath();
        ctx.arc(centerX, centerY, this.width / 2, 0, Math.PI * 2);
        ctx.fill();
        
        // Contorno
        ctx.strokeStyle = '#BF360C';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        
        // Remover sombra para detalhes
        ctx.shadowColor = 'transparent';
        
        // Desenhar detalhes faciais (estilo alienígena/monstro)
        // Olhos (três olhos em triângulo)
        const alienEyeSize = 5;
        
        // Olho superior
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(centerX, centerY - 10, alienEyeSize, 0, Math.PI * 2);
        ctx.fill();
        
        // Olho inferior esquerdo
        ctx.beginPath();
        ctx.arc(centerX - 9, centerY + 3, alienEyeSize, 0, Math.PI * 2);
        ctx.fill();
        
        // Olho inferior direito
        ctx.beginPath();
        ctx.arc(centerX + 9, centerY + 3, alienEyeSize, 0, Math.PI * 2);
        ctx.fill();
        
        // Pupilas (todas apontando na mesma direção)
        ctx.fillStyle = '#FF3D00';
        
        // Pupilas (menores)
        const alienPupilSize = 2;
        ctx.beginPath();
        ctx.arc(centerX + 1, centerY - 10, alienPupilSize, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.beginPath();
        ctx.arc(centerX - 8, centerY + 3, alienPupilSize, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.beginPath();
        ctx.arc(centerX + 10, centerY + 3, alienPupilSize, 0, Math.PI * 2);
        ctx.fill();
        
        // Boca (forma tentacular)
        ctx.fillStyle = '#BF360C';
        ctx.beginPath();
        ctx.arc(centerX, centerY + 12, 7, 0, Math.PI, false);
        ctx.fill();
        
        // Linhas dentro da boca para dar aspecto tentacular
        ctx.strokeStyle = '#7F0000';
        ctx.lineWidth = 1;
        
        // Linha vertical central
        ctx.beginPath();
        ctx.moveTo(centerX, centerY + 12);
        ctx.lineTo(centerX, centerY + 19);
        ctx.stroke();
        
        // Linhas diagonais (como tentáculos)
        ctx.beginPath();
        ctx.moveTo(centerX - 3, centerY + 15);
        ctx.lineTo(centerX - 6, centerY + 18);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(centerX + 3, centerY + 15);
        ctx.lineTo(centerX + 6, centerY + 18);
        ctx.stroke();
        
        // Adicionar textura circular em torno do corpo
        if (this.frameX === 1) { // Alternar conforme a animação
          ctx.strokeStyle = 'rgba(239, 108, 0, 0.3)';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(centerX, centerY, this.width * 0.6, 0, Math.PI * 2);
          ctx.stroke();
        }
        break;
    }
    
    // Adicionar marcador para modo de perseguição (comum a todos os tipos)
    if (this.avoidanceTimer > 0) {
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.arc(centerX, centerY, this.width * 0.8, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]); // Restaurar linha contínua
    }
    
    ctx.restore();
  }

  constrainToMap(map: Map): void {
    // Keep enemy within map bounds
    if (this.x < 0) this.x = 0;
    if (this.y < 0) this.y = 0;
    if (this.x + this.width > map.width) this.x = map.width - this.width;
    if (this.y + this.height > map.height) this.y = map.height - this.height;
  }
}
