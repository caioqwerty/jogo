export class Sprite {
  x: number;
  y: number;
  width: number;
  height: number;

  constructor(x: number, y: number, width: number, height: number) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }

  update(_deltaTime: number, ..._args: any[]): void {
    // Base update method to be overridden by child classes
  }

  draw(ctx: CanvasRenderingContext2D): void {
    // Base draw method to be overridden by child classes
    ctx.fillStyle = '#000000';
    ctx.fillRect(this.x, this.y, this.width, this.height);
  }

  // Get collision box (can be overridden by child classes to provide custom collision)
  getCollisionBox(): { x: number; y: number; width: number; height: number } {
    return {
      x: this.x,
      y: this.y,
      width: this.width,
      height: this.height,
    };
  }
}
