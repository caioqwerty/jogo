import { InputHandler } from './InputHandler';
import { Sprite } from './Sprite';
import { Map } from './Map';
import { Projectile } from './Projectile';

export class Player extends Sprite {
  speed: number;
  isMoving: boolean;
  direction: 'left' | 'right' | 'up' | 'down';
  frameX: number;
  frameY: number;
  maxFrames: number;
  frameTimer: number;
  frameInterval: number;
  health: number;
  invulnerable: boolean;
  invulnerableTimer: number;
  projectiles: Projectile[];
  attackCooldown: number;
  attackCooldownTimer: number;

  constructor(x: number, y: number, width: number, height: number, speed: number) {
    super(x, y, width, height);
    this.speed = speed;
    this.isMoving = false;
    this.direction = 'down';
    this.frameX = 0;
    this.frameY = 0;
    this.maxFrames = 3; // Number of animation frames
    this.frameTimer = 0;
    this.frameInterval = 0.2; // Time between frame changes
    this.health = 100;
    this.invulnerable = false;
    this.invulnerableTimer = 0;
    this.projectiles = [];
    this.attackCooldown = 0.3; // Tempo de espera entre ataques (segundos)
    this.attackCooldownTimer = 0;
  }

  update(deltaTime: number, inputHandler: InputHandler, map?: Map, collisionDetector?: any): void {
    // Reset movement flag
    this.isMoving = false;

    // Handle invulnerability timer
    if (this.invulnerable) {
      this.invulnerableTimer -= deltaTime;
      if (this.invulnerableTimer <= 0) {
        this.invulnerable = false;
      }
    }

    // Handle attack cooldown
    if (this.attackCooldownTimer > 0) {
      this.attackCooldownTimer -= deltaTime;
    }

    // Armazenar posição atual para poder reverter em caso de colisão
    const originalX = this.x;
    const originalY = this.y;
    let newX = originalX;
    let newY = originalY;

    // Handle player movement
    if (inputHandler.keys.includes('ArrowUp') || inputHandler.keys.includes('w')) {
      newY = originalY - this.speed;
      this.isMoving = true;
      this.direction = 'up';
      this.frameY = 3; // Animation row for up direction
    }

    if (inputHandler.keys.includes('ArrowDown') || inputHandler.keys.includes('s')) {
      newY = originalY + this.speed;
      this.isMoving = true;
      this.direction = 'down';
      this.frameY = 0; // Animation row for down direction
    }

    if (inputHandler.keys.includes('ArrowLeft') || inputHandler.keys.includes('a')) {
      newX = originalX - this.speed;
      this.isMoving = true;
      this.direction = 'left';
      this.frameY = 1; // Animation row for left direction
    }

    if (inputHandler.keys.includes('ArrowRight') || inputHandler.keys.includes('d')) {
      newX = originalX + this.speed;
      this.isMoving = true;
      this.direction = 'right';
      this.frameY = 2; // Animation row for right direction
    }
    
    // Verificar colisões e ajustar a posição apenas se o mapa e o detector estiverem disponíveis
    if (map && collisionDetector) {
      // Verificar colisão com obstáculos do mapa
      const validPosition = collisionDetector.checkMapCollisionWithAdjustment(
        this, 
        map, 
        newX, 
        newY
      );
      
      // Atualizar para a posição validada após checar colisões
      this.x = validPosition.x;
      this.y = validPosition.y;
      
      // Verificar se houve movimento apesar da colisão
      this.isMoving = this.x !== originalX || this.y !== originalY;
    } else {
      // Se não temos detector de colisão, apenas atualizar posição
      this.x = newX;
      this.y = newY;
    }

    // Atacar com a tecla de espaço
    if (inputHandler.keys.includes(' ') && this.attackCooldownTimer <= 0) {
      this.attack();
      this.attackCooldownTimer = this.attackCooldown;
    }

    // Atualizar projéteis
    this.projectiles = this.projectiles.filter(projectile => {
      projectile.update(deltaTime);
      
      // Verificar colisão de projéteis com obstáculos do mapa
      if (map && collisionDetector) {
        if (collisionDetector.checkMapCollision(projectile, map)) {
          // Projétil colidiu com obstáculo, remover
          return false;
        }
      }
      
      return projectile.lifespan > 0;
    });

    // Handle animation frames
    if (this.isMoving) {
      this.frameTimer += deltaTime;
      if (this.frameTimer >= this.frameInterval) {
        this.frameTimer = 0;
        this.frameX = (this.frameX + 1) % this.maxFrames;
      }
    } else {
      this.frameX = 0; // Reset to standing frame when not moving
    }
  }
  
  // Método para atacar
  attack(): void {
    let projectileX = this.x;
    let projectileY = this.y;
    
    // Ajustar a posição inicial do projétil baseado na direção
    switch (this.direction) {
      case 'up':
        projectileX = this.x + this.width / 2 - 4; // Centralizar
        projectileY = this.y - 8; // Acima do jogador
        break;
      case 'down':
        projectileX = this.x + this.width / 2 - 4; // Centralizar
        projectileY = this.y + this.height; // Abaixo do jogador
        break;
      case 'left':
        projectileX = this.x - 8; // À esquerda do jogador
        projectileY = this.y + this.height / 2 - 4; // Centralizar
        break;
      case 'right':
        projectileX = this.x + this.width; // À direita do jogador
        projectileY = this.y + this.height / 2 - 4; // Centralizar
        break;
    }
    
    // Criar e adicionar o projétil
    this.projectiles.push(new Projectile(projectileX, projectileY, this.direction));
  }

  draw(ctx: CanvasRenderingContext2D): void {
    // Draw player's projectiles first (so they appear behind player if needed)
    this.projectiles.forEach(projectile => {
      projectile.draw(ctx);
    });
    
    // Draw player as a more detailed pixel character
    ctx.save();
    
    // Flash effect when invulnerable
    if (this.invulnerable && Math.floor(Date.now() / 100) % 2 === 0) {
      ctx.globalAlpha = 0.5;
    }
    
    // Create a shadow for depth
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = 5;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 2;
    
    // Create a gradient for the body for better appearance
    const bodyGradient = ctx.createLinearGradient(
      this.x, 
      this.y, 
      this.x, 
      this.y + this.height
    );
    bodyGradient.addColorStop(0, '#66BB6A'); // Light green
    bodyGradient.addColorStop(1, '#388E3C'); // Darker green
    
    // Draw character body with rounded corners for a smoother look
    ctx.fillStyle = bodyGradient;
    const radius = 5; // Corner radius
    
    // Draw rounded rectangle
    ctx.beginPath();
    ctx.moveTo(this.x + radius, this.y);
    ctx.lineTo(this.x + this.width - radius, this.y);
    ctx.quadraticCurveTo(this.x + this.width, this.y, this.x + this.width, this.y + radius);
    ctx.lineTo(this.x + this.width, this.y + this.height - radius);
    ctx.quadraticCurveTo(this.x + this.width, this.y + this.height, this.x + this.width - radius, this.y + this.height);
    ctx.lineTo(this.x + radius, this.y + this.height);
    ctx.quadraticCurveTo(this.x, this.y + this.height, this.x, this.y + this.height - radius);
    ctx.lineTo(this.x, this.y + radius);
    ctx.quadraticCurveTo(this.x, this.y, this.x + radius, this.y);
    ctx.closePath();
    ctx.fill();
    
    // Add an outline to the character
    ctx.strokeStyle = '#1B5E20'; // Very dark green
    ctx.lineWidth = 1;
    ctx.stroke();
    
    // Remove shadow for precise features
    ctx.shadowColor = 'transparent';
    
    // Determine face details based on direction
    const faceOffsetY = this.direction === 'up' ? -2 : 0;
    const faceOffsetX = this.direction === 'left' ? -2 : (this.direction === 'right' ? 2 : 0);
    
    // Draw eyes with more detail (white background + pupils)
    const eyeSize = 5;
    const eyeSpacing = 12; // Distance between eyes
    const eyeCenterY = this.y + this.height * 0.3 + faceOffsetY;
    const leftEyeX = this.x + this.width / 2 - eyeSpacing / 2 + faceOffsetX;
    const rightEyeX = this.x + this.width / 2 + eyeSpacing / 2 + faceOffsetX;
    
    // Draw eye whites
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(leftEyeX, eyeCenterY, eyeSize, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(rightEyeX, eyeCenterY, eyeSize, 0, Math.PI * 2);
    ctx.fill();
    
    // Draw pupils with direction indicators
    ctx.fillStyle = '#000000';
    const pupilSize = 2.5;
    let pupilOffsetX = 0;
    let pupilOffsetY = 0;
    
    // Adjust pupil position based on direction
    if (this.direction === 'left') pupilOffsetX = -1.5;
    if (this.direction === 'right') pupilOffsetX = 1.5;
    if (this.direction === 'up') pupilOffsetY = -1.5;
    if (this.direction === 'down') pupilOffsetY = 1.5;
    
    // Draw pupils
    ctx.beginPath();
    ctx.arc(leftEyeX + pupilOffsetX, eyeCenterY + pupilOffsetY, pupilSize, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(rightEyeX + pupilOffsetX, eyeCenterY + pupilOffsetY, pupilSize, 0, Math.PI * 2);
    ctx.fill();
    
    // Draw mouth with more detail based on direction
    const mouthY = this.y + this.height * 0.7 + faceOffsetY;
    const mouthCenterX = this.x + this.width / 2 + faceOffsetX;
    
    // Different mouth shapes for different directions
    if (this.direction === 'up') {
      // Surprised "O" mouth
      ctx.beginPath();
      ctx.fillStyle = '#333333';
      ctx.arc(mouthCenterX, mouthY, 4, 0, Math.PI * 2);
      ctx.fill();
    } else if (this.direction === 'down') {
      // Happy smile
      ctx.beginPath();
      ctx.strokeStyle = '#333333';
      ctx.lineWidth = 2;
      ctx.arc(mouthCenterX, mouthY, 6, 0, Math.PI);
      ctx.stroke();
    } else {
      // Neutral line for left/right
      ctx.beginPath();
      ctx.strokeStyle = '#333333';
      ctx.lineWidth = 2;
      ctx.moveTo(mouthCenterX - 5, mouthY);
      ctx.lineTo(mouthCenterX + 5, mouthY);
      ctx.stroke();
    }
    
    // Add blush circles for a cute effect
    if (this.isMoving) {
      ctx.fillStyle = 'rgba(255, 99, 71, 0.3)';
      ctx.beginPath();
      ctx.arc(this.x + this.width * 0.25, this.y + this.height * 0.5, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(this.x + this.width * 0.75, this.y + this.height * 0.5, 4, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Draw a small accessory (like a hat or antenna)
    ctx.fillStyle = '#FF9800'; // Orange color
    ctx.beginPath();
    ctx.moveTo(this.x + this.width / 2, this.y);
    ctx.lineTo(this.x + this.width / 2 + 3, this.y - 5);
    ctx.lineTo(this.x + this.width / 2 - 3, this.y - 5);
    ctx.closePath();
    ctx.fill();
    
    ctx.restore();
  }

  constrainToMap(map: Map): void {
    // Keep player within map bounds
    if (this.x < 0) this.x = 0;
    if (this.y < 0) this.y = 0;
    if (this.x + this.width > map.width) this.x = map.width - this.width;
    if (this.y + this.height > map.height) this.y = map.height - this.height;
  }

  takeDamage(amount: number): void {
    // Only take damage if not invulnerable
    if (!this.invulnerable) {
      this.health -= amount;
      if (this.health < 0) this.health = 0;
      
      // Become invulnerable for a short period
      this.invulnerable = true;
      this.invulnerableTimer = 1; // 1 second of invulnerability
    }
  }
}
