import { Sprite } from './Sprite';

export class Collectible extends Sprite {
  rotation: number;
  rotationSpeed: number;
  hoverOffset: number;
  hoverSpeed: number;
  hoverTime: number;
  collectibleType: number;

  constructor(x: number, y: number, width: number, height: number) {
    super(x, y, width, height);
    this.rotation = 0;
    this.rotationSpeed = Math.random() * 0.05 + 0.02;
    this.hoverOffset = 0;
    this.hoverSpeed = Math.random() * 2 + 1;
    this.hoverTime = Math.random() * Math.PI * 2;
    this.collectibleType = Math.floor(Math.random() * 3); // 0, 1, or 2 for different types
  }

  update(deltaTime: number): void {
    // Rotate the collectible
    this.rotation += this.rotationSpeed;
    
    // Make it hover up and down
    this.hoverTime += deltaTime * this.hoverSpeed;
    this.hoverOffset = Math.sin(this.hoverTime) * 3;
  }

  draw(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    
    // Adicionar sombra sob o coletável
    ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
    ctx.shadowBlur = 10;
    ctx.shadowOffsetX = 2;
    ctx.shadowOffsetY = 5;
    
    // Move to center of collectible for rotation
    ctx.translate(this.x + this.width / 2, this.y + this.height / 2 + this.hoverOffset);
    
    // Desenhar um círculo de brilho/aura ao redor do item (pulsando)
    const glowSize = (Math.sin(this.hoverTime * 2) * 0.2 + 1) * this.width * 0.7;
    
    // Different colors and glows based on collectible type
    if (this.collectibleType === 0) {
      // Moeda dourada com brilho
      const coinGlow = ctx.createRadialGradient(0, 0, 0, 0, 0, glowSize);
      coinGlow.addColorStop(0, 'rgba(255, 215, 0, 0.7)');
      coinGlow.addColorStop(0.7, 'rgba(255, 215, 0, 0.3)');
      coinGlow.addColorStop(1, 'rgba(255, 215, 0, 0)');
      
      ctx.fillStyle = coinGlow;
      ctx.beginPath();
      ctx.arc(0, 0, glowSize, 0, Math.PI * 2);
      ctx.fill();
      
      // Remover sombra para detalhes precisos
      ctx.shadowColor = 'transparent';
      
      // Rotacionar para efeito 3D realista
      ctx.rotate(this.rotation);
      
      // Base da moeda (ouro/dourado)
      const coinGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.width / 2);
      coinGradient.addColorStop(0, '#FFF9C4'); // Amarelo muito claro (reflexo)
      coinGradient.addColorStop(0.4, '#FFD700'); // Dourado
      coinGradient.addColorStop(1, '#FFA000'); // Dourado mais escuro (borda)
      
      ctx.fillStyle = coinGradient;
      ctx.beginPath();
      ctx.arc(0, 0, this.width / 2, 0, Math.PI * 2);
      ctx.fill();
      
      // Contorno da moeda
      ctx.strokeStyle = '#F57F17';
      ctx.lineWidth = 1;
      ctx.stroke();
      
      // Detalhes centrais da moeda (símbolos ou marcações)
      ctx.fillStyle = '#F57F17';
      
      // Símbolo de estrela simplificada
      const symbolSize = this.width * 0.3;
      
      // Desenhar um asterisco simples
      for (let i = 0; i < 3; i++) {
        const angle = (Math.PI / 3) * i;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(-Math.cos(angle) * symbolSize, -Math.sin(angle) * symbolSize);
        ctx.lineTo(Math.cos(angle) * symbolSize, Math.sin(angle) * symbolSize);
        ctx.stroke();
      }
      
      // Círculo central
      ctx.beginPath();
      ctx.arc(0, 0, symbolSize * 0.3, 0, Math.PI * 2);
      ctx.fill();
      
      // Adicionar reflexo brilhante
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.beginPath();
      ctx.ellipse(-this.width * 0.15, -this.width * 0.15, this.width * 0.15, this.width * 0.1, Math.PI / 4, 0, Math.PI * 2);
      ctx.fill();
      
    } else if (this.collectibleType === 1) {
      // Gema azul com brilho
      const gemGlow = ctx.createRadialGradient(0, 0, 0, 0, 0, glowSize);
      gemGlow.addColorStop(0, 'rgba(33, 150, 243, 0.7)');
      gemGlow.addColorStop(0.7, 'rgba(33, 150, 243, 0.3)');
      gemGlow.addColorStop(1, 'rgba(33, 150, 243, 0)');
      
      ctx.fillStyle = gemGlow;
      ctx.beginPath();
      ctx.arc(0, 0, glowSize, 0, Math.PI * 2);
      ctx.fill();
      
      // Remover sombra para detalhes precisos
      ctx.shadowColor = 'transparent';
      
      // Rotacionar para efeito visual
      ctx.rotate(this.rotation);
      
      // Criar gradiente para a gema
      const gemGradient = ctx.createLinearGradient(-this.width/2, -this.height/2, this.width/2, this.height/2);
      gemGradient.addColorStop(0, '#E3F2FD'); // Azul muito claro
      gemGradient.addColorStop(0.3, '#90CAF9'); // Azul claro
      gemGradient.addColorStop(0.6, '#2196F3'); // Azul médio
      gemGradient.addColorStop(1, '#1565C0'); // Azul escuro
      
      // Desenhar formato de diamante mais complexo
      ctx.fillStyle = gemGradient;
      
      const gemShape = 8; // Número de pontas para um diamante lapidado
      const outerRadius = this.width * 0.5;
      const innerRadius = this.width * 0.35;
      
      ctx.beginPath();
      for (let i = 0; i < gemShape; i++) {
        const radius = i % 2 === 0 ? outerRadius : innerRadius;
        const angle = (Math.PI * 2 / gemShape) * i;
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.closePath();
      ctx.fill();
      
      // Adicionar contorno
      ctx.strokeStyle = '#0D47A1';
      ctx.lineWidth = 1;
      ctx.stroke();
      
      // Adicionar facetas e reflexos
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.beginPath();
      ctx.moveTo(0, -this.height * 0.25);
      ctx.lineTo(this.width * 0.2, 0);
      ctx.lineTo(0, this.height * 0.1);
      ctx.closePath();
      ctx.fill();
      
      // Adicionar mais reflexos
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.beginPath();
      ctx.arc(-this.width * 0.15, -this.height * 0.1, this.width * 0.1, 0, Math.PI * 2);
      ctx.fill();
      
    } else {
      // Estrela verde mágica com brilho
      const starGlow = ctx.createRadialGradient(0, 0, 0, 0, 0, glowSize * 1.2);
      starGlow.addColorStop(0, 'rgba(76, 175, 80, 0.7)');
      starGlow.addColorStop(0.5, 'rgba(76, 175, 80, 0.3)');
      starGlow.addColorStop(1, 'rgba(76, 175, 80, 0)');
      
      ctx.fillStyle = starGlow;
      ctx.beginPath();
      ctx.arc(0, 0, glowSize * 1.2, 0, Math.PI * 2);
      ctx.fill();
      
      // Remover sombra para detalhes precisos
      ctx.shadowColor = 'transparent';
      
      // Adicionar rotação mais lenta
      ctx.rotate(this.rotation * 0.7);
      
      // Gradiente para a estrela
      const starGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, this.width / 2);
      starGradient.addColorStop(0, '#B9F6CA'); // Verde muito claro
      starGradient.addColorStop(0.6, '#4CAF50'); // Verde médio
      starGradient.addColorStop(1, '#2E7D32'); // Verde escuro
      
      // Desenhar a estrela com mais pontas e detalhes
      const spikes = 5;
      const outerRadius = this.width * 0.5;
      const innerRadius = this.width * 0.2;
      
      ctx.fillStyle = starGradient;
      ctx.beginPath();
      
      for (let i = 0; i < spikes * 2; i++) {
        const radius = i % 2 === 0 ? outerRadius : innerRadius;
        const angle = (Math.PI / spikes) * i;
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      
      ctx.closePath();
      ctx.fill();
      
      // Adicionar contorno à estrela
      ctx.strokeStyle = '#1B5E20';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      
      // Adicionar centro brilhante
      const pulseSize = (Math.sin(this.hoverTime * 3) * 0.3 + 0.7) * this.width * 0.2;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.beginPath();
      ctx.arc(0, 0, pulseSize, 0, Math.PI * 2);
      ctx.fill();
      
      // Adicionar algumas partículas orbitando
      ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
      for (let i = 0; i < 3; i++) {
        const particleAngle = this.hoverTime * 2 + (Math.PI * 2 / 3) * i;
        const distance = this.width * 0.7;
        const particleX = Math.cos(particleAngle) * distance;
        const particleY = Math.sin(particleAngle) * distance;
        const particleSize = this.width * 0.07;
        
        ctx.beginPath();
        ctx.arc(particleX, particleY, particleSize, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    
    ctx.restore();
  }
}
