import React, { useEffect, useRef, useState } from 'react';
import { Player } from './Player';
import { Enemy } from './Enemy';
import { Collectible } from './Collectible';
import { Map } from './Map';
import { InputHandler } from './InputHandler';
import { CollisionDetector } from './CollisionDetector';
import { useAudio } from '../lib/stores/useAudio';
import { useGame } from '../lib/stores/useGame';

interface GameProps {
  onBackToMenu: () => void;
}

const Game: React.FC<GameProps> = ({ onBackToMenu }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [health, setHealth] = useState(100);
  const [paused, setPaused] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [level, setLevel] = useState(1);
  const animationFrameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);
  
  // Game objects
  const playerRef = useRef<Player | null>(null);
  const enemiesRef = useRef<Enemy[]>([]);
  const collectiblesRef = useRef<Collectible[]>([]);
  const mapRef = useRef<Map | null>(null);
  const inputHandlerRef = useRef<InputHandler | null>(null);
  const collisionDetectorRef = useRef<CollisionDetector | null>(null);

  // Audio utilities
  const { playHit, playSuccess } = useAudio();
  const { phase, start, end, restart } = useGame();
  
  // Initialize game
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Initialize input handler
    inputHandlerRef.current = new InputHandler();
    
    // Initialize map
    mapRef.current = new Map(canvas.width, canvas.height);
    
    // Initialize player
    playerRef.current = new Player(
      canvas.width / 2 - 16, // center x
      canvas.height / 2 + 100, // lower y
      32, // width
      32, // height
      3, // speed
    );
    
    // Initialize collision detector
    collisionDetectorRef.current = new CollisionDetector();
    
    // Create initial enemies
    createEnemies(level);
    
    // Create initial collectibles
    createCollectibles(level);
    
    // Start the game
    start();
    
    // Start game loop
    lastTimeRef.current = performance.now();
    animationFrameRef.current = requestAnimationFrame(gameLoop);
    
    // Cleanup on unmount
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      
      // Remove event listeners
      if (inputHandlerRef.current) {
        inputHandlerRef.current.removeListeners();
      }
    };
  }, [start, level]);
  
  // Create enemies based on level
  const createEnemies = (level: number) => {
    const canvas = canvasRef.current;
    const map = mapRef.current;
    const collisionDetector = collisionDetectorRef.current;
    
    if (!canvas || !map || !collisionDetector) return;
    
    // Clear existing enemies
    enemiesRef.current = [];
    
    // Create more enemies as level increases
    const enemyCount = 2 + level;
    
    // Tentativas máximas para encontrar uma posição válida
    const maxAttempts = 50;
    
    for (let i = 0; i < enemyCount; i++) {
      // Random position but avoid player starting area and obstacles
      let x = canvas.width / 2;
      let y = canvas.height / 2;
      let isValidPosition = false;
      let attempts = 0;
      
      // Tamanho do inimigo
      const enemyWidth = 32;
      const enemyHeight = 32;
      
      // Evitar bordas do mapa
      const borderMargin = 40;
      
      while (!isValidPosition && attempts < maxAttempts) {
        // Gerar uma posição aleatória dentro do mapa, evitando as bordas
        x = borderMargin + Math.random() * (canvas.width - enemyWidth - borderMargin * 2);
        y = borderMargin + Math.random() * (canvas.height - enemyHeight - borderMargin * 2);
        
        // Verificar se não está na área inicial do jogador
        const tooCloseToPlayer = 
          Math.abs(x - canvas.width / 2) < 150 && 
          Math.abs(y - canvas.height / 2) < 150;
        
        if (tooCloseToPlayer) {
          attempts++;
          continue;
        }
        
        // Criar um sprite temporário para testar colisão
        const tempEnemy = new Enemy(x, y, enemyWidth, enemyHeight, 1);
        
        // Verificar colisão com obstáculos
        const hasCollision = collisionDetector.checkMapCollision(tempEnemy, map);
        
        if (!hasCollision) {
          isValidPosition = true;
        }
        
        attempts++;
      }
      
      // Se não conseguimos encontrar uma posição válida após muitas tentativas,
      // tente uma abordagem diferente em áreas menos densas do mapa
      if (!isValidPosition) {
        // Dividir o mapa em 4 quadrantes e tentar em cada um
        const quadrants = [
          { x: borderMargin, y: borderMargin }, // Topo esquerdo
          { x: canvas.width / 2, y: borderMargin }, // Topo direito
          { x: borderMargin, y: canvas.height / 2 }, // Inferior esquerdo
          { x: canvas.width / 2, y: canvas.height / 2 }  // Inferior direito
        ];
        
        // Tente cada quadrante
        for (const quadrant of quadrants) {
          if (isValidPosition) break;
          
          for (let j = 0; j < 10; j++) {
            // Gerar posição dentro do quadrante
            x = quadrant.x + Math.random() * (canvas.width / 2 - enemyWidth - borderMargin);
            y = quadrant.y + Math.random() * (canvas.height / 2 - enemyHeight - borderMargin);
            
            // Verifique se não está muito perto do jogador
            const tooCloseToPlayer = 
              Math.abs(x - canvas.width / 2) < 150 && 
              Math.abs(y - canvas.height / 2) < 150;
            
            if (tooCloseToPlayer) continue;
            
            // Verificar colisão
            const tempEnemy = new Enemy(x, y, enemyWidth, enemyHeight, 1);
            const hasCollision = collisionDetector.checkMapCollision(tempEnemy, map);
            
            if (!hasCollision) {
              isValidPosition = true;
              break;
            }
          }
        }
      }
      
      // Se ainda assim não encontrou posição, use um ponto fixo seguro para spawn
      if (!isValidPosition) {
        const safePoints = [
          { x: canvas.width * 0.2, y: canvas.height * 0.2 },
          { x: canvas.width * 0.8, y: canvas.height * 0.2 },
          { x: canvas.width * 0.2, y: canvas.height * 0.8 },
          { x: canvas.width * 0.8, y: canvas.height * 0.8 }
        ];
        
        // Escolher um ponto aleatório da lista
        const safePoint = safePoints[Math.floor(Math.random() * safePoints.length)];
        x = safePoint.x;
        y = safePoint.y;
      }
      
      // Verificação de segurança para garantir que x e y estejam definidos
      if (typeof x !== 'number' || typeof y !== 'number') {
        // Usar uma posição padrão segura se algo der errado
        x = canvas.width / 2;
        y = canvas.height / 2;
      }
      
      // Increase speed slightly with level
      const speed = 1 + (level * 0.2);
      
      // Criar inimigo na posição válida encontrada
      enemiesRef.current.push(
        new Enemy(x, y, enemyWidth, enemyHeight, speed)
      );
    }
  };
  
  // Create collectibles based on level
  const createCollectibles = (level: number) => {
    const canvas = canvasRef.current;
    const map = mapRef.current;
    const collisionDetector = collisionDetectorRef.current;
    
    if (!canvas || !map || !collisionDetector) return;
    
    // Clear existing collectibles
    collectiblesRef.current = [];
    
    // Create collectibles
    const collectibleCount = 5 + level;
    const collectibleSize = 20;
    const borderMargin = 40; // Margem para evitar as bordas do mapa
    const maxAttempts = 30; // Tentativas máximas para encontrar uma posição válida
    
    for (let i = 0; i < collectibleCount; i++) {
      // Inicializar x e y com valores default para evitar erros de TypeScript
      let x = canvas.width / 2;
      let y = canvas.height / 2;
      let isValidPosition = false;
      let attempts = 0;
      
      // Tentar encontrar uma posição válida (sem colisões com obstáculos)
      while (!isValidPosition && attempts < maxAttempts) {
        // Gerar posição aleatória dentro do mapa, evitando as bordas
        x = borderMargin + Math.random() * (canvas.width - collectibleSize - borderMargin * 2);
        y = borderMargin + Math.random() * (canvas.height - collectibleSize - borderMargin * 2);
        
        // Criar um coletável temporário para verificar colisões
        const tempCollectible = new Collectible(x, y, collectibleSize, collectibleSize);
        
        // Verificar colisão com obstáculos
        const hasObstacleCollision = collisionDetector.checkMapCollision(tempCollectible, map);
        
        // Verificar se está longe o suficiente de outros coletáveis (para evitar aglomerações)
        let tooCloseToOther = false;
        const minDistance = collectibleSize * 3; // Distância mínima entre coletáveis
        
        for (const existingCollectible of collectiblesRef.current) {
          const dx = existingCollectible.x - x;
          const dy = existingCollectible.y - y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < minDistance) {
            tooCloseToOther = true;
            break;
          }
        }
        
        // Se não colidir com obstáculos e não estiver muito perto de outros coletáveis
        if (!hasObstacleCollision && !tooCloseToOther) {
          isValidPosition = true;
        }
        
        attempts++;
      }
      
      // Se chegamos aqui e a posição ainda não é válida, usar uma estratégia diferente
      if (!isValidPosition) {
        // Tentar posições em uma grade para distribuir os coletáveis de forma mais uniforme
        const gridCellSize = 100;
        const gridCols = Math.floor(canvas.width / gridCellSize);
        const gridRows = Math.floor(canvas.height / gridCellSize);
        
        // Escolher uma célula aleatória da grade
        let foundValidCell = false;
        
        for (let attempt = 0; attempt < 10 && !foundValidCell; attempt++) {
          const gridCol = Math.floor(Math.random() * gridCols);
          const gridRow = Math.floor(Math.random() * gridRows);
          
          // Calcular posição central da célula da grade
          x = gridCol * gridCellSize + gridCellSize / 2 - collectibleSize / 2;
          y = gridRow * gridCellSize + gridCellSize / 2 - collectibleSize / 2;
          
          // Evitar as bordas do mapa
          if (x < borderMargin || x + collectibleSize > canvas.width - borderMargin ||
              y < borderMargin || y + collectibleSize > canvas.height - borderMargin) {
            continue;
          }
          
          // Verificar colisão com obstáculos
          const tempCollectible = new Collectible(x, y, collectibleSize, collectibleSize);
          const hasObstacleCollision = collisionDetector.checkMapCollision(tempCollectible, map);
          
          if (!hasObstacleCollision) {
            foundValidCell = true;
            isValidPosition = true;
          }
        }
      }
      
      // Se ainda não encontramos uma posição válida, usar uma lista de pontos pré-definidos seguros
      if (!isValidPosition) {
        const safePoints = [
          { x: canvas.width * 0.25, y: canvas.height * 0.25 },
          { x: canvas.width * 0.75, y: canvas.height * 0.25 },
          { x: canvas.width * 0.25, y: canvas.height * 0.75 },
          { x: canvas.width * 0.75, y: canvas.height * 0.75 },
          { x: canvas.width * 0.5, y: canvas.height * 0.5 }
        ];
        
        // Escolher um ponto seguro que não colida com obstáculos
        for (const point of safePoints) {
          const tempCollectible = new Collectible(point.x, point.y, collectibleSize, collectibleSize);
          if (!collisionDetector.checkMapCollision(tempCollectible, map)) {
            x = point.x;
            y = point.y;
            isValidPosition = true;
            break;
          }
        }
        
        // Se ainda assim não encontrou uma posição, usar o centro do mapa como último recurso
        if (!isValidPosition) {
          x = canvas.width / 2 - collectibleSize / 2;
          y = canvas.height / 2 - collectibleSize / 2;
        }
      }
      
      // Verificação de segurança para garantir que x e y estejam definidos
      if (typeof x !== 'number' || typeof y !== 'number') {
        // Usar uma posição padrão segura se algo der errado
        x = canvas.width / 2 - collectibleSize / 2;
        y = canvas.height / 2 - collectibleSize / 2;
      }
      
      // Adicionar o coletável na posição encontrada
      collectiblesRef.current.push(
        new Collectible(x, y, collectibleSize, collectibleSize)
      );
    }
  };

  // Main game loop
  const gameLoop = (timestamp: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Calculate delta time in seconds
    const deltaTime = (timestamp - lastTimeRef.current) / 1000;
    lastTimeRef.current = timestamp;
    
    // Skip update if game is paused
    if (!paused && !gameOver) {
      update(deltaTime);
    }
    
    // Render
    render(ctx);
    
    // Continue loop
    animationFrameRef.current = requestAnimationFrame(gameLoop);
  };
  
  // Update game state
  const update = (deltaTime: number) => {
    const player = playerRef.current;
    const inputHandler = inputHandlerRef.current;
    const collisionDetector = collisionDetectorRef.current;
    const map = mapRef.current;
    
    if (!player || !inputHandler || !collisionDetector || !map) return;
    
    // Update player position based on input - agora passando o mapa e detector de colisão
    player.update(deltaTime, inputHandler, map, collisionDetector);
    
    // Ainda mantém o jogador dentro dos limites do mapa
    player.constrainToMap(map);
    
    // Update enemies
    enemiesRef.current = enemiesRef.current.filter(enemy => {
      // Atualizar inimigos, também passando mapa e detector de colisão
      enemy.update(deltaTime, player, map, collisionDetector);
      enemy.constrainToMap(map);
      
      // Check for collision with player
      if (collisionDetector.checkCollision(player, enemy)) {
        player.takeDamage(10);
        setHealth(prev => {
          const newHealth = Math.max(0, prev - 10);
          if (newHealth <= 0) {
            setGameOver(true);
            end();
          }
          return newHealth;
        });
        playHit();
      }
      
      // Verificar colisões com projéteis
      for (let i = player.projectiles.length - 1; i >= 0; i--) {
        const projectile = player.projectiles[i];
        if (collisionDetector.checkCollision(projectile, enemy)) {
          // Remover o projétil quando atingir um inimigo
          player.projectiles.splice(i, 1);
          
          // Inimigo derrotado, aumentar pontuação
          setScore(prev => prev + 20);
          playHit();
          
          // Remover o inimigo
          return false;
        }
      }
      
      return true;
    });
    
    // Criar novos inimigos se todos forem derrotados
    if (enemiesRef.current.length === 0) {
      setLevel(prev => {
        const newLevel = prev + 1;
        createEnemies(newLevel);
        return newLevel;
      });
    }
    
    // Check collectibles
    collectiblesRef.current = collectiblesRef.current.filter(collectible => {
      if (collisionDetector.checkCollision(player, collectible)) {
        // Increase score
        setScore(prev => prev + 10);
        playSuccess();
        return false;
      }
      return true;
    });
    
    // Level up if all collectibles are collected
    if (collectiblesRef.current.length === 0) {
      setLevel(prev => {
        const newLevel = prev + 1;
        createEnemies(newLevel);
        createCollectibles(newLevel);
        return newLevel;
      });
    }
  };
  
  // Render game
  const render = (ctx: CanvasRenderingContext2D) => {
    const player = playerRef.current;
    const map = mapRef.current;
    
    if (!player || !map) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    
    // Draw map
    map.draw(ctx);
    
    // Draw collectibles
    collectiblesRef.current.forEach(collectible => {
      collectible.draw(ctx);
    });
    
    // Draw enemies
    enemiesRef.current.forEach(enemy => {
      enemy.draw(ctx);
    });
    
    // Draw player
    player.draw(ctx);
    
    // Draw UI
    drawUI(ctx);
  };
  
  // Draw user interface
  const drawUI = (ctx: CanvasRenderingContext2D) => {
    const player = playerRef.current;
    const map = mapRef.current;
    
    if (!player || !map) return;
    
    // Health bar
    ctx.fillStyle = '#333333';
    ctx.fillRect(20, 20, 200, 20);
    ctx.fillStyle = health > 20 ? '#4CAF50' : '#FF5252';
    ctx.fillRect(20, 20, (health / 100) * 200, 20);
    ctx.strokeStyle = '#000000';
    ctx.strokeRect(20, 20, 200, 20);
    
    // Score and level
    ctx.font = '20px Arial';
    ctx.fillStyle = '#FFFFFF';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;
    ctx.textAlign = 'left';
    
    // Add text shadow effect for better readability
    ctx.strokeText(`Pontos: ${score}`, ctx.canvas.width - 150, 30);
    ctx.fillText(`Pontos: ${score}`, ctx.canvas.width - 150, 30);
    
    ctx.strokeText(`Nível: ${level}`, ctx.canvas.width - 150, 60);
    ctx.fillText(`Nível: ${level}`, ctx.canvas.width - 150, 60);
    
    // Draw mini-map
    drawMiniMap(ctx, player, map);
    
    // Game over screen
    if (gameOver) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      
      ctx.font = '48px Arial';
      ctx.fillStyle = '#FF5252';
      ctx.textAlign = 'center';
      ctx.fillText('Fim de Jogo', ctx.canvas.width / 2, ctx.canvas.height / 2 - 50);
      
      ctx.font = '24px Arial';
      ctx.fillStyle = '#FFFFFF';
      ctx.fillText(`Pontuação Final: ${score}`, ctx.canvas.width / 2, ctx.canvas.height / 2 + 10);
      ctx.fillText(`Nível Alcançado: ${level}`, ctx.canvas.width / 2, ctx.canvas.height / 2 + 50);
      
      ctx.font = '20px Arial';
      ctx.fillText('Clique para voltar ao menu', ctx.canvas.width / 2, ctx.canvas.height / 2 + 100);
    }
    
    // Pause screen
    if (paused && !gameOver) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
      ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);
      
      ctx.font = '48px Arial';
      ctx.fillStyle = '#FFFFFF';
      ctx.textAlign = 'center';
      ctx.fillText('Jogo Pausado', ctx.canvas.width / 2, ctx.canvas.height / 2 - 30);
      
      ctx.font = '20px Arial';
      ctx.fillText('Pressione P para continuar', ctx.canvas.width / 2, ctx.canvas.height / 2 + 30);
      ctx.fillText('ESC para voltar ao menu', ctx.canvas.width / 2, ctx.canvas.height / 2 + 60);
    }
  };
  
  // Função para desenhar o mini-mapa
  const drawMiniMap = (ctx: CanvasRenderingContext2D, player: Player, map: Map) => {
    // Tamanho e posição do mini-mapa
    const miniMapSize = 150;
    const miniMapX = ctx.canvas.width - miniMapSize - 20;
    const miniMapY = ctx.canvas.height - miniMapSize - 20;
    const scale = miniMapSize / map.width;
    
    // Desenhar fundo do mini-mapa
    ctx.save();
    
    // Fundo com borda
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)'; // Fundo mais escuro para melhor contraste
    ctx.fillRect(miniMapX, miniMapY, miniMapSize, miniMapSize);
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.strokeRect(miniMapX, miniMapY, miniMapSize, miniMapSize);
    
    // Desenhar grama de fundo no mini-mapa
    ctx.fillStyle = 'rgba(154, 205, 50, 0.3)'; // Verde claro semi-transparente
    ctx.fillRect(miniMapX, miniMapY, miniMapSize, miniMapSize);
    
    // Desenhar obstáculos no mini-mapa
    map.obstacles.forEach((obstacle, index) => {
      const obstacleX = miniMapX + obstacle.x * scale;
      const obstacleY = miniMapY + obstacle.y * scale;
      const obstacleWidth = obstacle.width * scale;
      const obstacleHeight = obstacle.height * scale;
      
      // Cores diferentes para diferentes tipos de obstáculos
      if (index < 4) {
        // Bordas do mapa
        ctx.fillStyle = '#333333'; // Cinza muito escuro para bordas
      } else if (map.objectType[index] === 'rock') {
        // Pedras
        ctx.fillStyle = '#777777'; // Cinza para pedras
      } else {
        // Árvores
        ctx.fillStyle = '#006400'; // Verde escuro para árvores
      }
      
      // Bordas são retângulos, pedras são círculos e árvores são círculos maiores
      if (index < 4) {
        ctx.fillRect(obstacleX, obstacleY, obstacleWidth, obstacleHeight);
      } else if (map.objectType[index] === 'rock') {
        ctx.beginPath();
        ctx.arc(
          obstacleX + obstacleWidth/2, 
          obstacleY + obstacleHeight/2, 
          obstacleWidth/2, 
          0, 
          Math.PI * 2
        );
        ctx.fill();
      } else {
        // Tronco da árvore
        ctx.fillStyle = '#8B4513'; // Marrom para o tronco
        ctx.fillRect(
          obstacleX + obstacleWidth/3, 
          obstacleY + obstacleHeight/2, 
          obstacleWidth/3, 
          obstacleHeight/2
        );
        
        // Copa da árvore
        ctx.fillStyle = '#006400'; // Verde escuro para a copa
        ctx.beginPath();
        ctx.arc(
          obstacleX + obstacleWidth/2, 
          obstacleY + obstacleHeight/3, 
          obstacleWidth/2, 
          0, 
          Math.PI * 2
        );
        ctx.fill();
      }
    });
    
    // Desenhar coletáveis no mini-mapa
    collectiblesRef.current.forEach(collectible => {
      const collectibleX = miniMapX + collectible.x * scale;
      const collectibleY = miniMapY + collectible.y * scale;
      const collectibleSize = collectible.width * scale;
      
      // Desenhar como estrelas para destacar
      ctx.fillStyle = '#FFD700'; // Dourado
      
      // Desenhar uma estrela simples (brilho)
      ctx.beginPath();
      ctx.arc(
        collectibleX + collectibleSize/2, 
        collectibleY + collectibleSize/2, 
        collectibleSize/2, 
        0, 
        Math.PI * 2
      );
      ctx.fill();
      
      // Adicionar brilho ao redor
      ctx.strokeStyle = '#FFFF00'; // Amarelo brilhante
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(
        collectibleX + collectibleSize/2, 
        collectibleY + collectibleSize/2, 
        collectibleSize/2 + 2, 
        0, 
        Math.PI * 2
      );
      ctx.stroke();
    });
    
    // Desenhar inimigos no mini-mapa
    enemiesRef.current.forEach(enemy => {
      const enemyX = miniMapX + enemy.x * scale;
      const enemyY = miniMapY + enemy.y * scale;
      const enemySize = enemy.width * scale;
      
      // Desenhar inimigos como quadrados vermelhos com borda
      ctx.fillStyle = '#FF0000'; // Vermelho vivo
      ctx.fillRect(enemyX, enemyY, enemySize, enemySize);
      
      // Adicionar borda aos inimigos para melhor visibilidade
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 1;
      ctx.strokeRect(enemyX, enemyY, enemySize, enemySize);
    });
    
    // Desenhar o jogador no mini-mapa com destaque
    const playerX = miniMapX + player.x * scale;
    const playerY = miniMapY + player.y * scale;
    const playerSize = player.width * scale;
    
    // Desenhar um círculo para a área de visão do jogador
    ctx.fillStyle = 'rgba(0, 255, 0, 0.1)'; // Verde claro semi-transparente
    ctx.beginPath();
    ctx.arc(
      playerX + playerSize/2, 
      playerY + playerSize/2, 
      playerSize * 4, 
      0, 
      Math.PI * 2
    );
    ctx.fill();
    
    // Desenhar o jogador com destaque
    ctx.fillStyle = '#00FF00'; // Verde brilhante
    ctx.fillRect(playerX, playerY, playerSize, playerSize);
    
    // Adicionar um contorno ao jogador
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.strokeRect(playerX, playerY, playerSize, playerSize);
    
    // Adicionar um indicador de direção ao jogador
    ctx.fillStyle = '#FFFFFF';
    const arrowSize = playerSize * 1.5;
    
    // Desenhar seta na direção do jogador
    ctx.save();
    ctx.translate(playerX + playerSize/2, playerY + playerSize/2);
    
    // Rotacionar com base na direção
    let angle = 0;
    switch(player.direction) {
      case 'up':
        angle = -Math.PI/2;
        break;
      case 'down':
        angle = Math.PI/2;
        break;
      case 'left':
        angle = Math.PI;
        break;
      case 'right':
        angle = 0;
        break;
    }
    
    ctx.rotate(angle);
    
    // Desenhar triângulo
    ctx.beginPath();
    ctx.moveTo(arrowSize/2, 0);
    ctx.lineTo(-arrowSize/2, -arrowSize/2);
    ctx.lineTo(-arrowSize/2, arrowSize/2);
    ctx.closePath();
    ctx.fill();
    
    ctx.restore();
    
    // Adicionar texto "Mini-mapa"
    ctx.fillStyle = '#FFFFFF';
    ctx.font = '14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Mini-mapa', miniMapX + miniMapSize/2, miniMapY - 5);
    
    ctx.restore();
  };
  
  // Handle pause toggle
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle pause with P key
      if (e.key === 'p' || e.key === 'P') {
        setPaused(prev => !prev);
      }
      
      // Return to menu with Escape key
      if (e.key === 'Escape') {
        onBackToMenu();
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onBackToMenu]);
  
  // Handle game over click to return to menu
  const handleCanvasClick = () => {
    if (gameOver) {
      onBackToMenu();
      restart();
    }
  };

  return (
    <div className="game-container">
      <canvas 
        ref={canvasRef} 
        width={800} 
        height={600}
        onClick={handleCanvasClick}
        className="game-canvas"
      />
      
      <div className="game-controls">
        <button 
          className="control-button"
          onClick={() => setPaused(prev => !prev)}
        >
          {paused ? "Continuar" : "Pausar"}
        </button>
        <button 
          className="control-button"
          onClick={onBackToMenu}
        >
          Menu Principal
        </button>
      </div>
    </div>
  );
};

export default Game;
