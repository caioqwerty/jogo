export class InputHandler {
  keys: string[];
  touchStartX: number;
  touchStartY: number;
  touchThreshold: number;

  constructor() {
    this.keys = [];
    this.touchStartX = 0;
    this.touchStartY = 0;
    this.touchThreshold = 30;
    
    // Set up event listeners
    window.addEventListener('keydown', this.keyDown.bind(this));
    window.addEventListener('keyup', this.keyUp.bind(this));
    
    // Touch controls for mobile
    window.addEventListener('touchstart', this.touchStart.bind(this));
    window.addEventListener('touchmove', this.touchMove.bind(this));
    window.addEventListener('touchend', this.touchEnd.bind(this));
  }

  keyDown(e: KeyboardEvent): void {
    // Only add key if it's not already in the array
    if (
      (e.key === 'ArrowDown' || 
       e.key === 'ArrowUp' || 
       e.key === 'ArrowLeft' || 
       e.key === 'ArrowRight' ||
       e.key === 'w' ||
       e.key === 'a' ||
       e.key === 's' ||
       e.key === 'd' ||
       e.key === ' ') && // Tecla de espaço para atacar
      this.keys.indexOf(e.key) === -1
    ) {
      this.keys.push(e.key);
    }
  }

  keyUp(e: KeyboardEvent): void {
    // Remove the key from the array
    if (
      e.key === 'ArrowDown' || 
      e.key === 'ArrowUp' || 
      e.key === 'ArrowLeft' || 
      e.key === 'ArrowRight' ||
      e.key === 'w' ||
      e.key === 'a' ||
      e.key === 's' ||
      e.key === 'd' ||
      e.key === ' ' // Tecla de espaço para atacar
    ) {
      this.keys.splice(this.keys.indexOf(e.key), 1);
    }
  }

  touchStart(e: TouchEvent): void {
    this.touchStartX = e.changedTouches[0].pageX;
    this.touchStartY = e.changedTouches[0].pageY;
  }

  touchMove(e: TouchEvent): void {
    const swipeDistanceX = e.changedTouches[0].pageX - this.touchStartX;
    const swipeDistanceY = e.changedTouches[0].pageY - this.touchStartY;
    
    // Clear previous touch directions
    this.keys = this.keys.filter(key => 
      key !== 'ArrowUp' && 
      key !== 'ArrowDown' && 
      key !== 'ArrowLeft' && 
      key !== 'ArrowRight'
    );
    
    // Determine direction based on swipe
    if (Math.abs(swipeDistanceX) > this.touchThreshold || Math.abs(swipeDistanceY) > this.touchThreshold) {
      if (Math.abs(swipeDistanceX) > Math.abs(swipeDistanceY)) {
        // Horizontal swipe
        if (swipeDistanceX > 0) {
          this.keys.push('ArrowRight');
        } else {
          this.keys.push('ArrowLeft');
        }
      } else {
        // Vertical swipe
        if (swipeDistanceY > 0) {
          this.keys.push('ArrowDown');
        } else {
          this.keys.push('ArrowUp');
        }
      }
      
      // Update touch start position for continuous movement
      this.touchStartX = e.changedTouches[0].pageX;
      this.touchStartY = e.changedTouches[0].pageY;
    }
  }

  touchEnd(): void {
    // Remove all directional keys when touch ends
    this.keys = this.keys.filter(key => 
      key !== 'ArrowUp' && 
      key !== 'ArrowDown' && 
      key !== 'ArrowLeft' && 
      key !== 'ArrowRight'
    );
  }

  removeListeners(): void {
    window.removeEventListener('keydown', this.keyDown.bind(this));
    window.removeEventListener('keyup', this.keyUp.bind(this));
    window.removeEventListener('touchstart', this.touchStart.bind(this));
    window.removeEventListener('touchmove', this.touchMove.bind(this));
    window.removeEventListener('touchend', this.touchEnd.bind(this));
  }
}
